############################################################################
############################################################################
###                                                                      ###
###                             LESSON 9                                 ###
###                      Inferential Statistics                          ###
###                         T-test and ANOVA                             ###
###                                                                      ###
############################################################################
############################################################################

# COMPARISON
# DV: Numeric
# Comparing MEAN


###########
# T.test: Mean for Numeric DV (equal or less than 2 categories)
###########




# ASSUMPTIONS for Parametric Tests: LARGE SAMPLE SIZE IS IMMUNE AGAINST THESES ASSUMPTIONS:

# 1] simple random sample
# 2] independent observation: [height of this individual is not related or affected by other individual height] occurrence of one observation provides no information about the occurrence of the other observation
# 3] independent groups [unrelated groups]

# 4] Homogeneity of variance: eqaual variances [sd^2]: variablity of the observations across groups are equal

# Levene's test: Homogeneity of variance: test H0 that the population variances are equal
# H0: the variances are equal: small p value => unequal variances


                   # p value >0.05 => equal varince


# 5] large sample [each group>30] or approximately normally distribution groups across the DV
# Pb => non-parametric tests OR Bootsrap [re-sample]



# 1] One sample T-tes: parametric method for a signle numeric variables [to compare outside mean value: population value]
####################

# we want test the null [mu] that the mean <55

# a: Examine data [Height variable]




# b: Run the test: population mean of height of babies 45 - 60 [will choose (H0) mu= 55]


# Does this sample mean  significantly greater than the population mean: one tailed [alpha level]



# Does this sample mean  significantly less (lower) than the population mean: one tailed



# Does this sample mean  significantly greater or lesser than the population mean: Two tailed



##########################

# 2] Independent sample T-test (Two-Sample T-Test): parametric method for a different in MEANS in 2 different population 

# examining the relationship between a numeric DV and a categorical IV [2 levels]

# DV: BMI [Numeric]
# IV: Sex [BINARY]

# Study question:

# Does  BMI differ between males and females in this sample and if yes is the difference statistically significant?

# H0: No difference in mean BMI between male and female [H0: Female BMI mean = Male BMI mean] [Male - Female =0]
# H1: There is a difference between mean BMI between females and males [ H1: Female mean ??? Male mean]

# a: Examine the data:



# b: Run the test: [unequal variances assumed]









# c: Assuming equal variance: after Levene's test



# d: Interpretation: [POPULATION]


# P value:

# 95% CI:

###############################

# 3] Paired t-tes [b4 and after in the same people]



# Is there a difference between blood pressure before and after therapy?
# H0: difference in BP = 0 [NO difference, no effect of this therapy]
# H1: there is a difference in mean between the two groups



###############################

# 4] Normality Violation: Non-Parametric alternative for Two-Sample T-Test
# Mann-Whitney U Test[Wilcoxon Rank-Sum Test]: Median [better to log]



# 5] LOG when normality violated:



# ASSUMPTIONS for Parametric: LARGE SAMPLE SIZE IS IMMUNE AGAINST THESES ASSUMPTIONS:

# 1] simple random sample
# 2] independent observation: [height of this individual is not related or affected by other individual height] occurrence of one observation provides no information about the occurrence of the other observation
# 3] independent groups [unrelated groups]
# 4] eqaual variances [sd]
# 5] large sample [each group>30] or approximately normally distribution groups across the DV
# Pb => non-parametric tests OR Bootsrap [re-sample]




###############
# ANOVA:
###############


# DV: numeric BMI
# IV: Smoking: categorical > 2 levels



# Study Question: Does BMI differ across smoking categories?

# H0: mean BMI across all smoking groups are equal [BMI mean across Never=BMI mean across Current=BMI mean across Previous] [No difference in BMI across the groups]
# H1: mean BMI are NOT equal between groups




# post hoc test [comparison between all groups after significant ANOVA]





# Normality Violation: Kruskal Wallis Test [better to log]



# OR LOG:



###################
# Proportion [2 Categorical variables]: DIFFERENCE in PROPORTIONS BETWEEN GROUPS
###################

# Sex and Smoke
# proportion [ e.g: male 367/725=0.51]
# Does proportion of indivduals with CHD differ between males and females?

# H0: P1=P2
# H1: P1#P2




