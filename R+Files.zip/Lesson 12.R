############################################################################
############################################################################
###                                                                      ###
###                             LESSON 12                                ###
###                      Inferential Statistics                          ###
###                         LINEAR REGRESSION                            ###
###                             [Mean]                                   ###
############################################################################
############################################################################

###################
# LINEAR REGRESSION: 
###################



# DV: Numeric [mean]
# Your IV maybe Numeric, Integer, Nominal, Ordinal, Binary
# Estimate: Beta Coefficient 

##############

# 1]: Define and check your variables

# Y: lung capacity
# X: smoking
# Covariates: Height, Gender, Age
# lm function




# Set you REFERENCE LEVELS:



# To change a reference:




# Check all levels have values:



# Check normality for numeric variables:



# Check linearity [Xs and Y:




# Multicollinearity [Xs: HIGH CORRELATION BETWEEN EXPOSURES:

#We do not want large values (> 10) of the variance inflation factor (collinearity)




#############

# 2] do Regression: lm

# H0: no significant differences between Xs and Y
# H1: there are significant differences between Xs and Y

# H0: B = 0
# H1: B # 0

# Y = a + �X

#a]: Simple:





# Lung Capacity = 7.7702 + 0.8753 * Smoking

# R^2 = 1%

# b]: Multiple:



# R^2 = 85%

# Lung Capacity =  -10.94754 + (-0.61774 * Smoking) + 0.16012 * Age + (-0.38528 * Gender) + 0.26363 * Height


# c]: All variables:



# d]: All variables except Gender and Age:



##################





###############

# 3] Report and plots

# REPORT:




# PLOT:







#############

# 4] check assumptions: for LINEAR REGRESSIOn:

# Assumptions: CLINE:

# Constant residuls variances [homoskedasticity vs heteroskadesticity]: residulas around the regression line are constant
# Linearity between Xs and Y [but NO Multicollinearity: no such love between Xs]
# Imdpendent Observations
# Normality of residuls
# Error [How Xs were built: sample selection]





################

# 5]: Compare models:

# a]: R^2


# b]: Partial F-Statistics: compare to original model

# H0: no significant difference between the models
# H1: there is difference between models






