############################################################################
############################################################################
###                                                                      ###
###                                                                      ###
###                            MIX and Tricks                            ###
###                                                                      ###
###                                                                      ###
############################################################################
############################################################################

#################
# MIX and Tricks:
#################





# Choose specific levels to be included in the analysis: |



# To make a variable as a factor/numeric/integer:



# To omit a level [specific level]:



# To make DUMMY VARIABLE [for all variables in the data]:




# Dummy for a specific variable:




# Change all data variable names:



# Change ONE COLUMN NAME:





# Change levels names:



# Change ONE level name:





# SET a reference level:




# Change an integer to factor with change level names:


# To categorize a numeric variable:





# To reorder the variables:



# How many values in this variable equal to:



# To remove an outlier:






# Check and Remove NA: include only complete cases

# a] Check: Missing Values:


# b) for Variable:



# c) for whole data:



# d) # cHanGE ALL NA in the data to 0



# Replace a specific value:[to change a specific value]






