############################################################################
############################################################################
###                                                                      ###
###                             LESSON 13                                ###
###                      Inferential Statistics                          ###
###                 Logistic Regression [Simple and Multiple]            ###
###                             [OR]                                     ###
############################################################################
############################################################################

# Revision: 

# Regression: modelling a relationship between two variables through linear equation [a, �]

# Regression Equation: How much change chnage in Y if we change X by the slope



# Simple vs Multiple

# Types of Regression

# linear regression: lm/ mean (beta coefficient)

# 1] Define your variables
# 2] Check the variables
# 3] Normality
# 4] Linearity [vif]
# 5] Create your model: Object <- lm(Y ~ Xs, data = data), then summary(Object)
# 6] Assumptions [gvlma]
# 7] Compare Models [R^2 and partial F-stat: anova]
# 8] Report [tab_model]
# 9] Plot [plot_summs]

####################


# Logistic Regression:


# DV: Binary
# IV: Any type
# Estimate: OR
# glm function

# OR= 1.4 => you have 40% higher risk to develop an event
# OR= 1 => No association between exposure and outcome
# OR= 0.8=> you have 20% lower risk to develop an event



# 1]: Define and check your variables

# Y: CHD
# X: BMI
# Covariates: Age, Smoking , Sex, Degree, HTN, DM


# Set your REFERENCE LEVELS:



# To change a reference:




# Check all levels have values: [smoking.as,factor: example of empty cells]




# 2]: Do Regression: glm

# H0: no significant association between Xs and Y
# H1: there is significant association between Xs and Y

# H0: OR = 1
# H1: OR # 1

# log(Y) = a + �X              [log(propability/1-probability)]

# a] Simple: CHD, BMI



# OR = 1.11


# b]: Multiple: After adjustment for...



# c]: All:



# 3]: Report:

# a]: Extract from the model:



# b] Our Lovely function:



# Logistic regression was used to estimate the relationship between CHD and BMI using a data from a random sample of 994 British individulas aged from 30 - 70.
# An increase in BMI by ONE unit will increase the risk of CHD in the population between 4% and 18% with best estimate of 11%.

# After adjusting/controlling for Age, Smoking, Sex and Degree, BMI was statistically significantly associated with CHD, OR = 1.13, 95% CI (1.05, 1.1.22), p = 0.001.





# 4] Check the models:

# AIC: the smaller the better [Akiki information criteria]



#  McFadden (Pseudo) R-squared

library(pscl) # Political Science Computaional Laboratory 





# Partial F-Statistics: compare to original model

# H0: no significant difference between the models
# H1: there is difference between models






# Multicollinearity: vif NOT > 10




