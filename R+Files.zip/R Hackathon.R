

############################################################################
############################################################################
###                                                                      ###
###                             R Hackathon                              ###
###                                                                      ###
############################################################################
############################################################################




#################
# R Hackathon
#################

# 400 Observations [4 Binary, 5 Numeric, 3 Categorical, 2 Integer]

# We want to build a data frame and do plots and tests


# 1] Create Objects

# 2] Build a data frame, read, write

# 3] Summary Statistics [summary, describe, freq, table, crosstab, CrossTable, Normality]

# 4] Plot [barplot, histogram, boxplot, scatterplot, qplot, ggplot]

# 5] Inferential Statistics [t.test, aov, cor, cor.test, chisq.test, OR, RR, Linear Regression, Logistic Regression]


############
# 1] Create Objects:
############

# Numeric: Grades




# Numeric: Weight



# Numeric: Height




# Numeric: BMI [weight in KG/squared height in meter]



# Numeric: Salary:



# Binary: Sex



# Binary: Diabetes [NOT SAMPLING]



# Binary: HTN [SAMPLING]



# Binary: CHD [SAMPLING]



# Integer : Age [SAMPLING]



# Integer : Rank[Non-SAMPLING]:



# Categorical : Smoking Status [more than the number]





# Categorical : Mood



# Categorical : Age CAT




#################
# 2] Build the data:
#################





# Change specific Column name:



# All names:



# Delete A variable



# Add A Variable:



# Subset: [all rows, columns: 1,2,3,5,6,7,8,12]




# Save:




#################
# 3] Descriptive Statistics:
#################



# Categorical Varaiables [descr]





# Numeric Variables [psych]






###############
# 4] Plots
###############


# barplot



# boxplot



# hist

hist(Height, breaks = 7, col = heat.colors(7))


# plot




# GGPLOT2:



# qplot



# ggplot




###############
# 5] Inferential Statistics
###############



#########
# t.test




###########
# aov





###########
# Proportiton:




#########
# OR 





#########
# RR




##########
# Chisq.test


##########
# Cor



# cor.test



##########
# Linear Regression








##########
# Logistic Regression





###########
# Cox Regression



###########
# Multinomial



###########
# Polynomial: 




