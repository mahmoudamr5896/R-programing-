############################################################################
############################################################################
###                                                                      ###
###                             LESSON 6                                 ###
### Descriptive statistics (freq, crosstab, table, describe, summary()   ###
###                                                                      ###
###                                                                      ###
############################################################################
############################################################################

# Data:



# a: Packages:



# b: example of DS:



##########
# NUMERIC:
##########


# c: Summary statistics [min, 1st quartile: (25th percentile), mean, median, 3rd quartile: (75th percentile), max]



# d: min, max, mean, median, sd: DESCRIBE



# For a numeric variable:



# For a numeric variable among different categories of catgeorical variable:



# e: mix of simple commands:





##########
# CATEGORiCAL:
##########

# f: frequency: FREQ



# Probability:



# g: TABLE for frequencies among one categorical variable:




# TABLE for frequencies among TWO categorical variables:




# h: crosstab for 2 catrgorical variables:



# i: CrossTable for 2 catrgorical variables [detailed]:



#########


# j: Normality:


# 1] Visually:

# a] boxplot and histogram*: Preferred



# b] Density line:





# c] qqplot: # As all the points fall approximately along this reference line, we can assume normality



# 2] Statistically: small sample size*

#  Shapiro test: H0: normality assumed => we want large p value to accept the null

