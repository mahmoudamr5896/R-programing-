############################################################################
############################################################################
###                                                                      ###
###                             LESSON 5                                 ###
###                         Import and Export                            ###
###                      Manipulating Data Frame                         ###
###                                                                      ###
############################################################################
############################################################################


# Review:

# Type of variables
# Building data frame [matrix, cbind, rbind, data.frame]
# Change columns name, rows name, reorder columns, remove columns, add coulmns


###############
# Import
###############



# For CSV:




# For Text:



###############
# Export
###############

# Export as CSV:




# Export as Excel:





############
# Remove objects:
############

# a]: one object:



# b] Remove everything except:



# c]: remove everything in the environment:



# d]: Remove selected objects:





###########
# Subset:
###########











# subset: just for columns



# |: or 



# >, <, >=, <=


# &






##########
# Values Location
##########




############
# Relevel:
############



# Change all data variable names:



# Change ONE COLUMN NAME:



# Change ONE level name:



# SET a reference level:


