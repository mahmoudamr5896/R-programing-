############################################################################
############################################################################
###                                                                      ###
###                             LESSON 11                                ###
###                      Inferential Statistics                          ###
###                           Regression                                 ###
###                            [Theory]                                  ###
############################################################################
############################################################################


# Revision:

# Descriptive Statistics: 
# library(psych) => summary(), describe()
# library(descr) => freq(), CrossTable(), table(), crosstab(), prob.table()
# plots => barplot(), boxplot(), hist(), plot(), library(ggplot2) => qpolt, ggplot

# Inferential Statistics:

# t.test()
# aov(), TukeyHSD() "honestly significant difference"
# prop.test()

# oddsratio, riskratio, epitab [2x2]
# chisq.test [nominal: nominal]
# cor, cor.test [numeric:numeric/rank]

#########################

# Variables:

# DV = Outcome = Response = Y

# IV = Exposure = Predictor = Explantory = X

#######

# 1] Categorical: Qualitative

# a]: Nominal non-ordinal: > 2 levels [Smoking Status: Never, previous, current]
# b]: Binary: 2 levels [Sex: Male, Female]
# c]: Ordinal > 2 levels but ORDERED [pain Level: Mild, Moderate, Severe] 

# 2] Quantitative

# a]: Numeric (Continuous): Height, Weight, BMI
# b]: Discrete [Integer]: whole number: Age [number of years]


##########
# What is Regression:
##########

# General set of methods for relating a function of an outcome variable to a predictor via linear equation.
# It is a way to model the relationship between two variables through linear equation [a, �]
# How much change in an outcome if we change an exposure by the SLOPE.

# Outcome = Intercept + Slope * Exposure
# Y = a + �X
# Y = a + 10X


#########
# Types of Regression:
#########

# a]:

# Simple: one DV/one IV [CHD = a + B * Smoking]
# Y = a + �X

# Multiple: one DV/multiple IVs [adjustment/controlling for confounders[covariates]] [CHD = a + B * Smoking + Age + Sex ...]
# Y = a + �X + �X2 +  �X3 + ...

# b]:

# Linear: numeric outcome (DV)
# Logistic: Binary outcome (DV)

# Cox: Time to event outcome (DV) [Survival Analysis]
# Polynomial: numerical DV with single IV with non-linear relationship
# Multinomial: nominal > 2 levels outcome

# c]: Regression [magnitude through linear equation] vs Correlation [strength and direction]


# r^2: Coefficients of determination [how much variation in Y can be explained by X] 

# residulas = difference between observed values and predicted values(regression line)
# 
# R^2 is calculated from the residulas