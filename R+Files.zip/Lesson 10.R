############################################################################
############################################################################
###                                                                      ###
###                             LESSON 10                                ###
###                      Inferential Statistics                          ###
###                 Chisquare, Correlation, OR and RR                    ###
###                                                                      ###
############################################################################
############################################################################

# Revision:


# Descriptive Statistics: 
# library(psych) => summary(), describe()
# library(descr) => freq(), CrossTable(), table(), crosstab(), prob.table()
# plots => barplot(), boxplot(), hist(), plot(), library(ggplot2) => qpolt, ggplot

# Inferential Statistics:
# t.test()
# aov(), TukeyHSD() "honestly significant difference"
# prop.test()


################

# 2x2 table

# 1]: Odds Ratio: probability/risk/odds

# 1]: Statistic that quantifies the strength of Association between exposure and outcome (Logistic Regression)
# 2]: For Case-Control Study [(odds of a dx in exposed/odds of a Healthy  in exposed)/(odds of a dx in NON-exposed/odds of a Healthy in NON-exposed )
# => odds of dx in Cases Exposed/odds of dx in Healthy Non-Exposed

# OR= 1.4 => you have 40% higher risk to develop an event
# OR= 1 => No association between exposure and outcome
# OR= 0.8=> you have 20% lower risk to develop an event


#               Outcome
#               Yes No
# Exposer        a   b
# No Exposure    c   d

# OR= a*d/b*c

# We are examining the relationship between smoking and heart dx: if you are a smoker, do you have more odds to develop heart dx?
# H0: OR =1
# H1: OR #1

# For OR and RR, we need to call this library:




# Two methods to get OR in R:




# a]:



# OR=0.64 => smoking lowers CHD risk by 36% [100-64]



# OR = 2.87 []

# or:


# b]:



###############

# 2]: Relative Risk: [probability fo event occuring in exposed/probability fo event occuring in non-exposed] [incidence rate in exposed/incidence rate in non-exposed]
# Used for measuring the association between exposures and outcomes in Cohort studies [prospective]

# RR= 1.4 => you have 40% higher risk to develop an event
# RR= 1 => No association between exposure and outcome
# RR= 0.8=> you have 20% lower risk to develop an event

# PROSPECTIVE

#               Outcome
#               Yes No
# Exposer        a   b
# No Exposure    c   d



# RR = (a/a+b)/(c/c+d)


# We are examining the relationship between smoking and heart dx: if you are a smoker, do you have more risk to develop heart dx?
# H0: RR =1
# H1: RR #1

# Two methods to get RR in R:



# a]



# or:



# b]





###########

# 3]: Chisquare: dependencies (Association) between 2 categorical variables [dependency only]

# Null hypothesis (H0): the row and the column variables of the contingency table are independent [no association between X and Y.
# Alternative hypothesis (H1): row and column variables are dependent [significant association]



# more than 2 values



##################

# 4] Correlation: 2 ND variablaes: [-1, 0, +1]: PEARSON CORRELATION COEFFIECIENT [r]



# Strength of the linear association between two numeric variables + the DIRECTION


# FIRST: PLOT:




#a]: r only with no testing

# Short code:



# r = 0.91 => 91%

# Long code:




# b]: Hypothesis testing for correlation:

# Is there a linear association between lung capacity and height? 
# H0: no correlation between height and lung capacity
# H1: There is a correlation between height and lung capacity

# Short code:



# Long Code:



# c]: for NON-Parametric SPEARMAN/KENDALL: Ordinal variable (ranks) and numeric variable

# BMI among an ordinal variable [Rank]

# r = -0.03

