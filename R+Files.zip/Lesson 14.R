############################################################################
############################################################################
###                                                                      ###
###                             LESSON 14                                ###
###                      Inferential Statistics                          ###
###       Other Forms of Regression [Cox, Multinomial, Polynomial]       ###
###                                                                      ###
############################################################################
############################################################################

# Revision: 

# Regression: modelling a relationship between two variables through linear equation [a, �]

# Regression Equation: How much change chnage in Y if we change X by the slope

# Y = a + B * Xs

# Simple vs Multiple

# Types of Regression

# linear regression: lm/ mean (beta coefficient)

# 1] Define your variables
# 2] Check the variables
# 3] Normality
# 4] Linearity [vif]
# 5] Create your model: Object <- lm(Y ~ Xs, data = data), then summary(Object)
# 6] Assumptions [gvlma]
# 7] Compare Models [R^2 and partial F-stat: anova]
# 8] Report [tab_model]
# 9] Plot [plot_summs]

# Logistic Regression:

# 1] Define your variables
# 2] Check the variables
# 3] Multicolinearity [vif]
# 4] Create your model: Object <- glm(Y ~ Xs, family = "binomial", data = data), then summary(Object)
# 5] Report [tab_model]
# 6] Compare Models [AIC, pR^2 and partial F-stat: anova]


#######

# Cox Proportional Hazards Model [HR]: Time to event [SURVIVAL ANALYSIS]
# It's logistic regression + time [prospective]
# Other form of LOGISTIC REGRESSION

# DV: Binary + Time
# IV any type
# Estimate: HR
# coxph: Cox Proportional Hazard 

# Hazard Ratio: The risk of having the event among those who are at risk of having the event at a particular time in the follow up period

# HR= 1.4 => you have 40% higher risk to develop an event
# HR= 1 => No association between exposure and outcome
# HR= 0.8=> you have 20% lower risk to develop an event





# 1]: Packages needed:





# time: Survival time in days
# status: censoring status 1=censored, 2=dead [dead is the event]
# age: Age in years
# sex: Male=1 Female=2


# 2]: Define your variables:

# Y: status [death or not] + time [in days]
# X: sex
# Covariate: age

# 3]: Build your Model simple vs multiple

# H0: HR = 1
# H1: HR # 1

# a] Simple


# HR = 1.70


# b] Multiple:





# Extrat Slopes:




# 95% CI:



# Report: Easier and quicker




# Compared to females, males have an elevated risk (67%) of dying from lung CA [1.23, 2.36] [statistically significant: p = 0.002]

#####################

# 2] # Multinomial [Categorical DV]: other form of LOGISTIC REGRESSION


# a: Packages



# b: Import data





# c: Define and check your variables:

# Y: BMI Categories [healthy, overweight, obese]
# X: Smoking
# Covariates: Age, Sex, Depression

# Set your REFERENCE LEVELS:



# To change a reference:




# Check all levels have values:




# d: Build you models [Simple, Multiple]




# e: Report [easier and quicker]




#####################

# 3] # Polynomial [Numeric DV: numeric IV BUT NON-LINEAR Relationship]:
# ther form of LINEAR REGRESSION

# special case of multiple linear regression
# Polynomial Linear Regression: variable with different powers
# 1 IV with multiple levels: non-straight line regression

# same variable to different powers
# numerical DV with single IV with non-linear relationship

# SLR: y = b0 + b1x1

# MLR: y = b0 + b1x1 + b2x2 + b3x3 ...bnxn

# PLR: y = b0 + b1x1 + b2x1^2 + b3x1^3 ...bnx1(^n)

# used in disease prevalence


# a]: Import and Check Linearity [DV: Salary, IV: Level]



# Check Linearity:




# b]: Build Linear Model [is it correct?]



# c]: use POLYNOMIAL:



# d]: compare the models [linear vs polynomial] partial F-Statistics
# H0: no significant difference between the models
# H1: there is difference between models



# R^2


# Y = -121333.3 +  180664.3 * Level + -48549.0 * Level ^ 2 ...




# we have evidence to believe that the model including height^2 provides a statistically significantly better fit than a model without it




