############################################################################
############################################################################
###                                                                      ###
###                             LESSON 7                                 ###
###                                                                      ###
###                              Plots                                   ###
###                                                                      ###
###                                                                      ###
############################################################################
############################################################################

# Review:

# Numeric: [library(psych)]
# summary, describe, fivenum, min, max, mean, median, sd

# Categorical: [library(descr)]
# freq, table, crosstab, CrossTable

# Normality:
# boxplot [symmetric, median in the middle of the box: skewness: the box is to one end], hist [normally distributed variable: symmetric, bell-shaped, most values in the middle around the mean]
# shapiro.test [small sample size: H0: normally distributed variable]



##############
# PLOT:
##############

Trial <- read.csv(file.choose())



# 1]: a: Barplot: Categorical variables frequencies and percentages [better in Excel]:

# Code: should be as a table or matrix 



# Color:

# 1: black
# 2: red
# 3: green
# 4: blue
# 5: sky blue
# 6: violet
# 7: yellow
# 8: grey


# Title: [main = name of the title] [cex.main: size of the title] [font.main= shape of the title] [col.main: color of the title]



# X axis and Y axis names: [xlab: naming X axis] [ylab: naming Y axis] [cex.lab: labs size] [col.lab: labs color]



# X and Y axes values [cex.axes: Y Axix values size], [cex.names: [X] variable levels names size] 
# [col.axis= X and Y axes values color] [ylim: specify y values] [las: direction of the text: 2 for X and 3 for Y]



# Bar size and shape: [border: color of the bar outline] [width: size of the bin] [space: between bins] [density: shape inside bins] [angle: directions of filling of the bins]



# Legend: site, name, color, with or without outline :bty





# Two Categorical variable: beside each other




# Save as or export




################
# Excel =>
################

# Counts:

# one categorical variable:



# 2 Categorical




# Percent:

# one categorical:


# 2 Categorical:




###############################################################


# 2]: Plot function [Scatterplot]: 2 Numeric [correlation] [plot(X,Y)]






# Lets ATTACH: to make life easier:



# pch: type of dot (16 filled dots), cex: size of dots, col: color of dots



# Add THIRD VARIABLE:

#we want to create plot of height and age by gender:




# we can add female on existing plot: points command:



# OR we can cut the plot screen to two and check both plots:



 # setting the screen back

###################


# 3]: Histogram: ONE numeric variable distribution




# lwd: line width, breaks: number of bins





#  histogram for one variable across different categories: Trial2



# Boxplot is better for comparing two groups




###################

# 4]: Boxplots: distribution of ONE numeric variable: five number summary display



# b]: by a category:




# c]:  One numeric by two categorical variables [Height in smoking categories among sex]




####################

# 5] GGPLOT2:







# to delete all plots:

dev.off()


