############################################################################
############################################################################
###                                                                      ###
###                             LESSON 8                                 ###
###                      Inferential Statistics                          ###
###                              Theory                                  ###
###                                                                      ###
############################################################################
############################################################################


#####
# Review:
#####

# Numeric: [library(psych)]
# summary, describe, fivenum, min, max, mean, median, sd

# Categorical: [library(descr)]
# freq, table, crosstab, CrossTable

#########

# Normality:
# boxplot [symmetric, median in the middle of the box: skewness: the box is to one end], hist [normally distributed variable: symmetric, bell-shaped, most values in the middle around the mean]
# shapiro.test [small sample size: H0: normally distributed variable]

#########

# Attach the data
# View and structure of the data

#########

# Categorical variable percentages and frequencies:

# barplot(table(categorical variable)) # one or two categorical variables 

#########

# ONE Numeric variable distribution (normality):

# boxplot(numeric variable) or boxplot(numeric variable ~ categorical variable) or boxplot(numeric variable ~ categorical variable*categorical variable2)

# hist(numeric variable) or hist(numeric variable[categorecal vaiable=="level])

#########

# TWO numeric variables correlation [scatterplot]

# plot(numeric(X(),Numeric(Y))

# plot(Numeric1[Categorical=="Level1],Numeric2[Categorical=="Level1])
# plot(Numeric1[Categorical=="Level2],Numeric2[Categorical=="Level2])

#########

# Title: 
# main =, cex.main = , font.main = , col.main = 

# Variables (X and Y): 
#xlab =, ylab =, cex.lab =, font.lab =, col.lab =

# Values and levels in X and Y:
# X: cex.names =, Y: cex.axis =
# X and Y: font.axis =, col.axis =

# pch: plot character
# cex: size of the dots in scatterplot
# col: color of the dots, boxplot, histogram

# breaks = number of bins
# border = color of the bins
# density = shape of the bins
# Angle = angle of shape inside the bins
# space = space between bins
# lwd: line width
# horizontal = T => horizontal plot


########

# GGPLOT2:

########

# qplot:
#######

# BARPLOT:
# qplot(Categorical, geom="bar")

# BOXPLOT:
# qplot(Numeric, geom="boxplot")
# qplot(Categorical, Numeric, geom="boxplot")


# HISTOGRAM:
# qplot(Numeric, geom="histogram", bins=7, col=I("black"), size=2, width=2, fill=I(3))


# Scatterplot:
# qplot(Numeric,Numeric, size=I(size of the dots), col=categorical)
# qplot(Numeric,Numeric, size=I(size of the dots), col=I(specify a color))



#####
# ggplot:
#####

# BARPLOT:
# ggplot(Data, aes(Categorical Variable)) + geom_bar()

# Boxplot:
# ggplot(Data, aes(Numeric Variable)) + geom_boxplot()
# ggplot(Data, aes(Categorical, Numeric Variable)) + geom_boxplot()

# Histogram:
# ggplot(Data, aes(Numeric Variable)) + geom_histogram()


#Scatterplot:
# ggplot(Data, aes(Numeric,Numeric)) + geom_point()


##################################

# type of variables [Categorical vs Numeric]

# Dependent Variable [Outcome, Response]


# Independent Variable [Exposure, Explanatory, Predictor, Risk Factor]



# Difference between Descriptive Statistics and Inferential Statistics [sample vs population]


# Test depends on 1] Comparison or Association, 2] DV and IV [ Real difference of just by CHANCE]

# 1]: Comparison:


# Numeric DV: Mean [T-Test and ANOVA]

# t-tes: DV: Numeric, IV: categorical with 2 levels [Height ~ Gender] [Male, Female]
# ANOVA: DV: Numeric, IV: Categorical > 2 levels [Height ~ Smoking.Status] [Never, Current, Ex-smokers]

# Categorical Variables: Proportion [2 levels]

# DV: Categorical

# 2] Associations:

# Numeric: Correlation and Linear Regression
# Categorical: Chisquare and Logistic Regression

# Hypothesis Testing:

# H0: null hypothesis [Male = Female] [Sex , DM]
# H1: Alternative hypothesis [Male # Female] 

# P value: To reject or accept the H0. [0.05]



# p value < 0.05 => we can reject the NULL hypothesis
# p value > 0.05 => we can accept the NULL hypothesis

# Chance of getting the null hypothesis in your test
# Is your result attributed to chance alone?

# p value < 0.05: the probability to observe this result or more extreme if null hypothesis is true => less than 5 in 100


# 0.05?
# = 0.05
# > 0.05

# 95% CI [POPULATION] better than P value [scientific significance] [SE: variability of the mean: how variable sample mean when samples differs]
# 95%: 2 +/- SE [remember SD??]

# Mean = 160 (mu)
# mean= 155 (95% CI: 145, 165)

# 95% CI [0]

# Height Male Female [170-155=15] 

# H0: Male-Female = 0

# 15 (-2,20) [p value > 0.05]
# 15 (6,20) [ p value < 0.05]

# 95% CI [1]
# H0: OR = 1

# OR = 1.23 [0.8, 2]
# OR = 1.23 [1.12,2]
