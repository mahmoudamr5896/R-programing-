############################################################################
############################################################################
###                                                                      ###
###                             LESSON 1                                 ###
###              Why R, instal R, R Studio, R interface                  ###
############################################################################
############################################################################


# 1]:

# FREE
# Easy to ACCESS
# Plenty of Packages


# 2]:

# To download R:

# https://cran.r-project.org/bin/windows/base/


# To download R Studio:

# https://rstudio.com/products/rstudio/download/


# 3]:

# Interface


# 4]:

# Help:


