############################################################################
############################################################################
###                                                                      ###
###                             LESSON 3                                 ###
###              open, save, directory, new script                       ###
###           Math in R, objects, meaning of ->, [], $, ()               ###
############################################################################
############################################################################

# Review:


# Run




# Directory



# Objects




# Library





# 1] Shortcuts:

# R is case sensitive

# Ctrl + ENTER
# Ctrl + O     
# Ctrl + Shift + N
# Ctrl + S
# Ctrl + L
# Alt + Dash <- 
# Ctrl + Shift + H
# Ctrl + Tab
# Ctrl + Shift + Tab
# Ctrl + Z
# Ctrl + C
# Ctrl + V
# Ctrl + X
# Ctrl + Shift + C

# I am practicing R


# 2] Math: +, -, *, /, ^, sqart





# 3] Elements and Objects: COMBINE + <- $ < > >= <= | ! & 

# <- : assignment
# c : combine
# $ : a variable within a data frame
# | : or
# > : more than
# < : less than
# >= more than or equal
# <= less than or equal
#!= not equal to



