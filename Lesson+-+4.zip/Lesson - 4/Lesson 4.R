############################################################################
############################################################################
###                                                                      ###
###                             LESSON 4                                 ###
###                         Type of Variables                            ###
###              Matrix, cbind, rbind and Data Frame                     ###
###                                                                      ###
############################################################################
############################################################################



# Review:

# Run
# Directory
# Library
# Shortcuts
# Math
# Elements







#####################
# Type of Variables:
#####################

# 1] Categorical: Qualitative

# a]: Nominal non-ordinal: > 2 levels [Smoking Status: Never, previous, current]
# b]: Binary: 2 levels [Sex: Male, Female]
# c]: Ordinal > 2 levels but ORDERED [pain Level: Mild, Moderate, Severe] 

# 2] Quantitative

# a]: Numeric (Continuous): Height, Weight, BMI
# b]: Discrete [Integer]: whole number: Age [number of years]



#####

Test <- read.csv(file.choose())

# remove:



# Delete everything except:

rm(list=setdiff(ls(), "Trial"))

#################
# Matrix, cbind, rbind: ONE TYPE
#################



# Build:

# a]: Objects



# b]: One Type [either numbers or text]



# c]: Multiple types [preferred]




# d]: Put it in an object:


# Change column names:




# Change row name:





# Reorder the Columns:




# To remove a variable:




# Add Column:




# Data frame in ONE line:

Mix <- data.frame(Sex=c("Male","Female","Male","Male"), Age=c(12,34,56,76), Height=c(120,150,16,180), Smoking.Status=c("Current","Previous","Current","Never"))


